/**
 * @file SimpleFormInsert.java
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Scheduling")
public class Scheduling extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public Scheduling() {
      super();
   }

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      String CUSTOMERFIRSTNAME = request.getParameter("CUSTOMERFIRSTNAME");
	      String CUSTOMERLASTNAME = request.getParameter("CUSTOMERLASTNAME");
	      String CUSTOMERPHONE = request.getParameter("CUSTOMERPHONE");
	      String CUSTOMEREMAIL = request.getParameter("CUSTOMEREMAIL");
	      String DATE = request.getParameter("DATE");
	      String TIMEFRAME = request.getParameter("TIMEFRAME");
	      String SERVICE = request.getParameter("SERVICE");
	      String EMPLOYEENAME = request.getParameter("EMPLOYEENAME");
	      
	      Connection connection = null;
	      String insertBookingSql = " INSERT INTO Booking (id, CUSTOMERFIRSTNAME, CUSTOMERLASTNAME, CUSTOMERPHONE, CUSTOMEREMAIL, DATE, TIMEFRAME, SERVICE, EMPLOYEENAME) VALUES (default, ?, ?, ?, ?, ?, ?, ?, ?) ";
	      String removeEmployeeASql = " DELETE FROM EmployeeA_Availability WHERE DATE = ? AND TIMEFRAME = ?";
	      String removeEmployeeBSql = " DELETE FROM EmployeeB_Availability WHERE DATE = ? AND TIMEFRAME = ?";
	      
      try {
         DBConnection.getDBConnection();
         connection = DBConnection.connection;
         PreparedStatement preparedStmt = connection.prepareStatement(insertBookingSql);	//Insert New Appointment into Booking table
         preparedStmt.setString(1, CUSTOMERFIRSTNAME);
         preparedStmt.setString(2, CUSTOMERLASTNAME);
         preparedStmt.setString(3, CUSTOMERPHONE);
         preparedStmt.setString(4, CUSTOMEREMAIL);
         preparedStmt.setString(5, DATE);
         preparedStmt.setString(6, TIMEFRAME);
         preparedStmt.setString(7, SERVICE);
         preparedStmt.setString(8, EMPLOYEENAME);
         preparedStmt.execute();
         connection.close();
         if (EMPLOYEENAME.compareTo("Aimlys") == 0) {		//If Aimlys is selected Employee, remove requested timeslot from her table
        	 	DBConnection.getDBConnection();
        	 	connection = DBConnection.connection;
        	 	PreparedStatement preparedStmt1 = connection.prepareStatement(removeEmployeeASql);
        	 	preparedStmt1.setString(1, DATE);
        	 	preparedStmt1.setString(2, TIMEFRAME);
             preparedStmt1.execute();
        	 	connection.close();
         }
         else if (EMPLOYEENAME.compareTo("Matthew") == 0) {	//If Matthew is selected Employee, remove requested timeslot from his table
     	 	DBConnection.getDBConnection();
     	 	connection = DBConnection.connection;
     	 	PreparedStatement preparedStmt2 = connection.prepareStatement(removeEmployeeBSql);
     	 	preparedStmt2.setString(1, DATE);
     	 	preparedStmt2.setString(2, TIMEFRAME);
            preparedStmt2.execute();
     	 	connection.close();
         }
         
         
      } catch (Exception e) {
         e.printStackTrace();
      }

      // Set response content type
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      String title = "Appointment Booked:";
      String docType = "<!doctype html public \"-//w3c//dtd html 4.0 " + "transitional//en\">\n";
      out.println(docType + //
            "<html>\n" + //
            "<head><title>" + title + "</title></head>\n" + //
            "<body bgcolor=\"#f0f0f0\">\n" + //
            "<h2 align=\"center\">" + title + "</h2>\n" + //
            "<ul>\n" + //

            "  <li><b>First Name</b>: " + CUSTOMERFIRSTNAME + "\n" + //
            "  <li><b>Last Name</b>: " + CUSTOMERLASTNAME + "\n" + //
            "  <li><b>Phone</b>: " + CUSTOMERPHONE + "\n" + //
            "  <li><b>E-mail</b>: " + CUSTOMEREMAIL + "\n" + //
            "  <li><b>Date</b>: " + DATE + "\n" + //
            "  <li><b>Time</b>: " + TIMEFRAME + "\n" + //
            "  <li><b>Type of Service</b>: " + SERVICE + "\n" + //
            "  <li><b>Employee</b>: " + EMPLOYEENAME + "\n" + //

            "</ul>\n");

      out.println("<a href=/Term-Project-JAMJ/scheduling.html>Book New Appointment</a> <br>");
      out.println("</body></html>");
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doGet(request, response);
   }

}